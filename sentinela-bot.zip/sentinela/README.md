# 🛡️ Sentinela Bot

Bot de diversão e economia para Discord com sistema de **Aura** como moeda.

## ✨ Comandos

### 💰 Economia
| Comando | Descrição | Cooldown |
|---|---|---|
| `/daily` | Colete 750–1250 Aura diária | 20h |
| `/trabalho` | Trabalhe para ganhar Aura | 1h |
| `/crime` | Tente a sorte no crime | 2h |
| `/roubar @user` | Roube Aura de alguém | 3h |
| `/apostar <valor>` | Caça-níquel | — |
| `/duelo @user <aposta>` | Duelo PvP de Aura | — |
| `/transferir @user <valor>` | Transfira Aura | — |
| `/perfil [@user]` | Veja perfil | — |
| `/ranking` | Top 10 de Aura | — |
| `/loja` | Itens da loja | — |
| `/comprar <item>` | Compre item | — |
| `/inventario` | Seu inventário | — |

### 🎮 Diversão
| Comando | Descrição |
|---|---|
| `/ship @p1 [@p2]` | Compatibilidade amorosa |
| `/casar @user` | Casamento (precisa de 💍 Anel) |
| `/divorciar` | Divórcio |
| `/giveaway` | Crie um sorteio |
| `/vod [tipo]` | Verdade ou Desafio |
| `/8ball <pergunta>` | Bola Mágica |
| `/rps` | Pedra, Papel, Tesoura |
| `/coinflip` | Cara ou Coroa |
| `/dado [lados]` | Role um dado |
| `/pp [@user]` | Medidor |
| `/gay [@user]` | Medidor 🌈 |
| `/impostora [@user]` | Among Us |
| `/escolher` | Decisão aleatória |
| `/meme` | Meme do Reddit |
| `/fato` | Fato curioso |
| `/conselho` | Conselho do dia |

### 🥰 Ações (com GIFs)
`/hug` `/kiss` `/slap` `/pat` `/punch` `/bite` `/cuddle` `/poke` `/highfive` `/wave` `/wink`

### 🔧 Utilidades
`/ping` `/avatar` `/userinfo` `/serverinfo` `/enquete` `/sortear` `/presentear` `/say` `/ajuda`

---

## 🚀 Como rodar

### 1. Clone e instale
```bash
git clone <seu-repo>
cd sentinela
npm install
```

### 2. Configure o .env
```bash
cp .env.example .env
```
Edite o `.env` com:
```
DISCORD_TOKEN=seu_token_aqui
CLIENT_ID=seu_client_id_aqui
```

### 3. Registre os comandos Slash
```bash
node deploy-commands.js
```

### 4. Inicie o bot
```bash
npm start
```

---

## 🌐 Deploy no Render

1. Crie um novo **Web Service** no Render
2. Conecte seu repositório GitHub
3. Configure:
   - **Build Command:** `npm install`
   - **Start Command:** `node index.js`
   - **Environment:** Node
4. Adicione as variáveis de ambiente:
   - `DISCORD_TOKEN`
   - `CLIENT_ID`
5. **Importante:** No Render, o SQLite salva em disco. Para persistência, considere usar um **Persistent Disk** no Render ou migrar para MongoDB/PostgreSQL no futuro.

### ⚠️ Persistência de dados no Render
O Render destrói arquivos do container entre deploys. Para manter os dados:
- Adicione um **Disk** no plano pago do Render e monte em `/data`
- Ou use o Railway, Fly.io, ou VPS para SQLite persistente

---

## 🛒 Itens da Loja

| Item | Preço | Efeito |
|---|---|---|
| 🛡️ Escudo de Aura | 500 | Protege contra roubo |
| 🍀 Amuleto da Sorte | 800 | Dobra o Daily |
| 🥷 Capa do Ladrão | 1200 | +15% de sucesso no crime |
| ⚗️ Poção de XP | 300 | +500 XP |
| 💍 Anel de Casamento | 2000 | Necessário para /casar |
| 🎟️ Ticket de Sorte | 150 | Sorte no giveaway |
| ✨ Elixir de Aura | 900 | +1000 Aura instantâneo |
| 💐 Buquê de Flores | 200 | Para presentear |

---

## 📁 Estrutura
```
sentinela/
├── index.js              # Entry point
├── deploy-commands.js    # Registra slash commands
├── .env                  # Tokens (não comitar!)
├── database/
│   └── db.js             # SQLite handler
├── commands/
│   ├── economia/         # Daily, crime, loja...
│   ├── diversao/         # Ship, casar, giveaway...
│   └── util/             # Ping, avatar, ajuda...
├── events/
│   ├── ready.js
│   └── interactionCreate.js
└── data/
    └── sentinela.db      # Banco de dados (auto-criado)
```
