const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

// GIFs locais de fallback por ação
const gifsFallback = {
  hug: 'https://media.giphy.com/media/od5H3PmEG5EVq/giphy.gif',
  kiss: 'https://media.giphy.com/media/zkppEMFvRX5HO/giphy.gif',
  slap: 'https://media.giphy.com/media/Zau0yrl17uhdK/giphy.gif',
  pat: 'https://media.giphy.com/media/5tmRHwTlHAA9WkX6Oj/giphy.gif',
  punch: 'https://media.giphy.com/media/yIPHGGDMNmGI8/giphy.gif',
  bite: 'https://media.giphy.com/media/JKBpMSMqHoMwOHHuuH/giphy.gif',
  cuddle: 'https://media.giphy.com/media/l2QDM9Jnim1YVILXa/giphy.gif',
  poke: 'https://media.giphy.com/media/5C0a8IItAWRebylgQD/giphy.gif',
  baka: 'https://media.giphy.com/media/fxe8v45NNXFd4jdaNI/giphy.gif',
  highfive: 'https://media.giphy.com/media/3oEjHV0z8S7WM4MwnK/giphy.gif',
  wave: 'https://media.giphy.com/media/ASd0Ukj0y3qMM/giphy.gif',
  wink: 'https://media.giphy.com/media/nIBpVQB3cwzXq/giphy.gif',
};

const frases = {
  hug: (a, b) => `${a} deu um abraço quentinho em ${b}! 🤗`,
  kiss: (a, b) => `${a} beijou ${b}! 💋`,
  slap: (a, b) => `${a} deu um tapa em ${b}! Ai! 👋`,
  pat: (a, b) => `${a} fez cafuné em ${b}! 🥺`,
  punch: (a, b) => `${a} deu um soco em ${b}! 🤛`,
  bite: (a, b) => `${a} mordeu ${b}! Autch! 😬`,
  cuddle: (a, b) => `${a} está aconchegado(a) com ${b}! 🥰`,
  poke: (a, b) => `${a} cutucou ${b}! Ei! 👉`,
  baka: (a, b) => `${a} chamou ${b} de BAKA! 😤`,
  highfive: (a, b) => `${a} deu um high five pra ${b}! ✋`,
  wave: (a, b) => `${a} acenou para ${b}! 👋`,
  wink: (a, b) => `${a} deu uma piscadela para ${b}! 😉`,
};

const cores = {
  hug: '#FF9F1C', kiss: '#FF69B4', slap: '#FF6B6B', pat: '#A0C4FF',
  punch: '#FF4500', bite: '#9B2226', cuddle: '#FFAFCC', poke: '#BDE0FE',
  baka: '#F72585', highfive: '#FFD166', wave: '#06D6A0', wink: '#FFC8DD',
};

function criarComandoAcao(nome, descricao) {
  return {
    data: new SlashCommandBuilder()
      .setName(nome)
      .setDescription(descricao)
      .addUserOption(opt =>
        opt.setName('usuario').setDescription('Quem vai receber a ação').setRequired(true)
      ),

    async execute(interaction) {
      const alvo = interaction.options.getUser('usuario');
      const autor = interaction.user;

      await interaction.deferReply();

      let gifUrl = gifsFallback[nome];
      try {
        const res = await axios.get(`https://nekos.life/api/v2/img/${nome}`, { timeout: 3000 });
        if (res.data?.url) gifUrl = res.data.url;
      } catch {
        // usa fallback
      }

      const embed = new EmbedBuilder()
        .setColor(cores[nome] || '#7B2FBE')
        .setDescription(frases[nome](autor, alvo))
        .setImage(gifUrl)
        .setFooter({ text: 'Sentinela Bot • Ações' })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    },
  };
}

// Exporta múltiplos comandos como array
module.exports = [
  criarComandoAcao('hug', '🤗 Dê um abraço em alguém'),
  criarComandoAcao('kiss', '💋 Dê um beijo em alguém'),
  criarComandoAcao('slap', '👋 Dê um tapa em alguém'),
  criarComandoAcao('pat', '🥺 Faça cafuné em alguém'),
  criarComandoAcao('punch', '🤛 Dê um soco em alguém'),
  criarComandoAcao('bite', '😬 Morda alguém'),
  criarComandoAcao('cuddle', '🥰 Aconchegue-se com alguém'),
  criarComandoAcao('poke', '👉 Cutuque alguém'),
  criarComandoAcao('highfive', '✋ Dê um high five pra alguém'),
  criarComandoAcao('wave', '👋 Acene para alguém'),
  criarComandoAcao('wink', '😉 Pisque o olho para alguém'),
];
