const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, addAura, removeAura } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('apostar')
    .setDescription('🎰 Aposte sua Aura!')
    .addIntegerOption(opt =>
      opt.setName('quantidade').setDescription('Quanto apostar').setRequired(true).setMinValue(10)
    ),

  async execute(interaction) {
    const aposta = interaction.options.getInteger('quantidade');
    const user = getUser(interaction.user.id, interaction.user.username);

    if (user.aura < aposta) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('❌ Aura insuficiente!')
          .setDescription(`Você tem apenas **${user.aura.toLocaleString('pt-BR')} ✨**`)],
        ephemeral: true,
      });
    }

    // Sistema de slots
    const simbolos = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣'];
    const pesos = [35, 25, 20, 10, 5, 3, 2]; // probabilidades

    function getSimbol() {
      const total = pesos.reduce((a, b) => a + b, 0);
      let rand = Math.random() * total;
      for (let i = 0; i < simbolos.length; i++) {
        rand -= pesos[i];
        if (rand <= 0) return simbolos[i];
      }
      return simbolos[0];
    }

    const s1 = getSimbol(), s2 = getSimbol(), s3 = getSimbol();
    const display = `[ ${s1} | ${s2} | ${s3} ]`;

    let multiplicador = 0;
    let mensagem = '';

    if (s1 === s2 && s2 === s3) {
      if (s1 === '7️⃣') { multiplicador = 10; mensagem = '🎊 **JACKPOT! TRIO DE 7!**'; }
      else if (s1 === '💎') { multiplicador = 7; mensagem = '💎 **TRIO DE DIAMANTES!**'; }
      else if (s1 === '⭐') { multiplicador = 5; mensagem = '⭐ **TRIO DE ESTRELAS!**'; }
      else { multiplicador = 3; mensagem = '🎉 **TRIO!**'; }
    } else if (s1 === s2 || s2 === s3 || s1 === s3) {
      multiplicador = 1.5;
      mensagem = '✨ **PAR!**';
    } else {
      multiplicador = 0;
      mensagem = '😢 **Não foi dessa vez...**';
    }

    let ganho = 0;
    let cor = '#FF6B6B';

    if (multiplicador > 0) {
      ganho = Math.floor(aposta * multiplicador);
      addAura(interaction.user.id, ganho - aposta);
      cor = '#00C851';
    } else {
      removeAura(interaction.user.id, aposta);
      ganho = -aposta;
    }

    const userAtual = getUser(interaction.user.id);

    const embed = new EmbedBuilder()
      .setColor(cor)
      .setTitle('🎰 Caça-Níquel')
      .setDescription(`${display}\n\n${mensagem}`)
      .addFields(
        { name: '💰 Aposta', value: `${aposta.toLocaleString('pt-BR')} ✨`, inline: true },
        { name: ganho >= 0 ? '📈 Ganho' : '📉 Perda', value: `${ganho >= 0 ? '+' : ''}${ganho.toLocaleString('pt-BR')} ✨`, inline: true },
        { name: '💼 Aura Atual', value: `${userAtual.aura.toLocaleString('pt-BR')} ✨`, inline: true },
      )
      .setFooter({ text: `Sentinela Bot • Slots${multiplicador >= 3 ? ' 🎊' : ''}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
