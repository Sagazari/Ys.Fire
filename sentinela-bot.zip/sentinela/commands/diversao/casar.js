const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { getUser, removeAura, hasItem, removeItem } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('casar')
    .setDescription('💒 Peça alguém em casamento!')
    .addUserOption(opt =>
      opt.setName('pessoa').setDescription('Com quem você quer se casar?').setRequired(true)
    ),

  async execute(interaction) {
    const alvo = interaction.options.getUser('pessoa');

    if (alvo.id === interaction.user.id) return interaction.reply({ content: '💀 Você não pode se casar consigo mesmo!', ephemeral: true });
    if (alvo.bot) return interaction.reply({ content: '🤖 Bots não casam!', ephemeral: true });

    const userSelf = getUser(interaction.user.id, interaction.user.username);
    const userAlvo = getUser(alvo.id, alvo.username);

    if (userSelf.casado_com) {
      return interaction.reply({ content: `💔 Você já é casado(a)! Use **/divorciar** primeiro.`, ephemeral: true });
    }
    if (userAlvo.casado_com) {
      return interaction.reply({ content: `💔 ${alvo.username} já está casado(a)!`, ephemeral: true });
    }

    // Verifica anel
    if (!hasItem(interaction.user.id, 'Anel de Casamento')) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('💍 Você precisa de um Anel de Casamento!')
          .setDescription('Compre um na **/loja** por **2.000 ✨ Aura** primeiro.')],
        ephemeral: true,
      });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('aceitar').setLabel('💒 Aceitar').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('recusar').setLabel('💔 Recusar').setStyle(ButtonStyle.Danger),
    );

    const embed = new EmbedBuilder()
      .setColor('#FF69B4')
      .setTitle('💍 Pedido de Casamento!')
      .setDescription(`${alvo}, **${interaction.user.username}** está te pedindo em casamento!\n\nVocê aceita? 💍`)
      .setFooter({ text: 'Você tem 60 segundos para responder.' })
      .setTimestamp();

    const msg = await interaction.reply({ content: `${alvo}`, embeds: [embed], components: [row], fetchReply: true });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      filter: i => i.user.id === alvo.id,
      time: 60000,
    });

    collector.on('collect', async i => {
      collector.stop();
      if (i.customId === 'aceitar') {
        removeItem(interaction.user.id, 'Anel de Casamento');
        const db = require('../../database/db').db;
        const data = new Date().toISOString();
        db.prepare('UPDATE usuarios SET casado_com = ?, data_casamento = ? WHERE id = ?')
          .run(alvo.id, data, interaction.user.id);
        db.prepare('UPDATE usuarios SET casado_com = ?, data_casamento = ? WHERE id = ?')
          .run(interaction.user.id, data, alvo.id);

        const embedAceito = new EmbedBuilder()
          .setColor('#FF69B4')
          .setTitle('🎊 Casamento realizado!')
          .setDescription(`${interaction.user} 💒 ${alvo}\n\n🎉 Parabéns ao casal! Que sejam muito felizes!`)
          .setFooter({ text: 'Sentinela Bot • Casamento' })
          .setTimestamp();

        await i.update({ embeds: [embedAceito], components: [] });
      } else {
        const embedRecusado = new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('💔 Pedido recusado...')
          .setDescription(`${alvo.username} recusou o pedido de ${interaction.user.username}.\n\n😔 Que triste...`)
          .setFooter({ text: 'Sentinela Bot • Casamento' });

        await i.update({ embeds: [embedRecusado], components: [] });
      }
    });

    collector.on('end', (_, reason) => {
      if (reason === 'time') {
        msg.edit({ components: [] }).catch(() => {});
      }
    });
  },
};
