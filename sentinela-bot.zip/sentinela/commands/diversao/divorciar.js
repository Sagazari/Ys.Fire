const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('divorciar')
    .setDescription('💔 Termine seu casamento... :('),

  async execute(interaction) {
    const user = getUser(interaction.user.id, interaction.user.username);

    if (!user.casado_com) {
      return interaction.reply({ content: '😅 Você nem é casado(a)!', ephemeral: true });
    }

    const db = require('../../database/db').db;
    db.prepare('UPDATE usuarios SET casado_com = NULL, data_casamento = NULL WHERE id = ?').run(interaction.user.id);
    db.prepare('UPDATE usuarios SET casado_com = NULL, data_casamento = NULL WHERE id = ?').run(user.casado_com);

    const embed = new EmbedBuilder()
      .setColor('#808080')
      .setTitle('💔 Divórcio finalizado')
      .setDescription(`${interaction.user.username} e <@${user.casado_com}> se divorciaram.\n\n😢 Que pena... nem o anel ficou.`)
      .setFooter({ text: 'Sentinela Bot • Divórcio' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
