const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { getUser, addAura, removeAura } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('duelo')
    .setDescription('⚔️ Desafie alguém para um duelo de Aura!')
    .addUserOption(opt => opt.setName('oponente').setDescription('Quem você quer desafiar').setRequired(true))
    .addIntegerOption(opt => opt.setName('aposta').setDescription('Quanto apostar').setRequired(true).setMinValue(50)),

  async execute(interaction) {
    const oponente = interaction.options.getUser('oponente');
    const aposta = interaction.options.getInteger('aposta');

    if (oponente.id === interaction.user.id) return interaction.reply({ content: '🤦 Você não pode se desafiar!', ephemeral: true });
    if (oponente.bot) return interaction.reply({ content: '🤖 Bots não aceitam duelos!', ephemeral: true });

    const desafiante = getUser(interaction.user.id, interaction.user.username);
    const rival = getUser(oponente.id, oponente.username);

    if (desafiante.aura < aposta) {
      return interaction.reply({ content: `❌ Você não tem **${aposta} ✨** para apostar!`, ephemeral: true });
    }
    if (rival.aura < aposta) {
      return interaction.reply({ content: `❌ ${oponente.username} não tem **${aposta} ✨** para apostar!`, ephemeral: true });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('duelo_aceitar').setLabel('⚔️ Aceitar Duelo').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('duelo_recusar').setLabel('🏳️ Recusar').setStyle(ButtonStyle.Secondary),
    );

    const embed = new EmbedBuilder()
      .setColor('#FF6B00')
      .setTitle('⚔️ Desafio de Duelo!')
      .setDescription(`${oponente}, **${interaction.user.username}** te desafia para um duelo!\n\n💰 Aposta: **${aposta.toLocaleString('pt-BR')} ✨ Aura**\n\nAceita o desafio?`)
      .setFooter({ text: 'Sentinela Bot • Duelo • 60s para responder' });

    const msg = await interaction.reply({ content: `${oponente}`, embeds: [embed], components: [row], fetchReply: true });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      filter: i => i.user.id === oponente.id,
      time: 60000,
    });

    collector.on('collect', async i => {
      collector.stop();
      if (i.customId === 'duelo_recusar') {
        return i.update({
          embeds: [new EmbedBuilder().setColor('#808080').setTitle('🏳️ Duelo recusado').setDescription(`${oponente.username} não aceitou o desafio. Covarde? 😄`)],
          components: [],
        });
      }

      // DUELO!
      await i.update({ components: [], embeds: [new EmbedBuilder().setColor('#FF6B00').setTitle('⚔️ Duelo em andamento...').setDescription('Rolando os dados...')] });

      const rollDesafiante = Math.floor(Math.random() * 100) + 1;
      const rollOponente = Math.floor(Math.random() * 100) + 1;

      let vencedor, perdedor, rollV, rollP;
      if (rollDesafiante >= rollOponente) {
        vencedor = interaction.user; perdedor = oponente;
        rollV = rollDesafiante; rollP = rollOponente;
      } else {
        vencedor = oponente; perdedor = interaction.user;
        rollV = rollOponente; rollP = rollDesafiante;
      }

      removeAura(perdedor.id, aposta);
      addAura(vencedor.id, aposta);

      const db = require('../../database/db').db;
      db.prepare('UPDATE usuarios SET wins = wins + 1 WHERE id = ?').run(vencedor.id);

      const embedFim = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('⚔️ Resultado do Duelo!')
        .addFields(
          { name: `🎯 ${interaction.user.username}`, value: `Dado: **${rollDesafiante}**`, inline: true },
          { name: `🎯 ${oponente.username}`, value: `Dado: **${rollOponente}**`, inline: true },
          { name: '🏆 Vencedor', value: `${vencedor} ganhou **${aposta.toLocaleString('pt-BR')} ✨ Aura**!`, inline: false },
        )
        .setFooter({ text: 'Sentinela Bot • Duelo' })
        .setTimestamp();

      await msg.edit({ embeds: [embedFim] });
    });

    collector.on('end', (_, reason) => {
      if (reason === 'time') msg.edit({ components: [] }).catch(() => {});
    });
  },
};
