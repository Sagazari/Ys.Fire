const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser } = require('../../database/db');

function parseDuracao(str) {
  const match = str.match(/^(\d+)(s|m|h|d)$/);
  if (!match) return null;
  const n = parseInt(match[1]);
  const map = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return n * map[match[2]];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('🎁 Crie um giveaway no servidor')
    .addStringOption(opt => opt.setName('premio').setDescription('O que vai ser sorteado?').setRequired(true))
    .addStringOption(opt => opt.setName('duracao').setDescription('Duração: ex: 10m, 1h, 2d').setRequired(true))
    .addIntegerOption(opt => opt.setName('vencedores').setDescription('Quantos vencedores?').setRequired(false).setMinValue(1).setMaxValue(10))
    .addIntegerOption(opt => opt.setName('aura').setDescription('Aura de prêmio (opcional)').setRequired(false).setMinValue(0)),

  async execute(interaction) {
    const premio = interaction.options.getString('premio');
    const duracaoStr = interaction.options.getString('duracao');
    const vencedores = interaction.options.getInteger('vencedores') || 1;
    const auraPremi = interaction.options.getInteger('aura') || 0;

    const duracao = parseDuracao(duracaoStr);
    if (!duracao) {
      return interaction.reply({ content: '❌ Duração inválida! Use: `10m`, `1h`, `2d`, etc.', ephemeral: true });
    }

    const terminaEm = new Date(Date.now() + duracao);
    const terminaTS = Math.floor(terminaEm.getTime() / 1000);

    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle('🎁 GIVEAWAY!')
      .setDescription(
        `**Prêmio:** ${premio}${auraPremi > 0 ? `\n**Aura:** ✨ ${auraPremi.toLocaleString('pt-BR')}` : ''}\n\n` +
        `Clique em 🎉 para participar!\n\n` +
        `⏰ Termina: <t:${terminaTS}:R>\n` +
        `🏆 Vencedores: **${vencedores}**\n` +
        `👥 Participantes: **0**`
      )
      .setFooter({ text: `Criado por ${interaction.user.username} • Sentinela Bot` })
      .setTimestamp(terminaEm);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('giveaway_entrar').setLabel('🎉 Participar').setStyle(ButtonStyle.Primary),
    );

    await interaction.reply({ content: '✅ Giveaway criado!', ephemeral: true });
    const msg = await interaction.channel.send({ embeds: [embed], components: [row] });

    // Salva no banco
    const db = require('../../database/db').db;
    db.prepare(`
      INSERT INTO giveaways (message_id, channel_id, guild_id, premio, aura, host_id, vencedores, termina_em)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(msg.id, interaction.channel.id, interaction.guild.id, premio, auraPremi, interaction.user.id, vencedores, terminaEm.toISOString());

    // Configura collector de botão
    const collector = msg.createMessageComponentCollector({ time: duracao });

    collector.on('collect', async i => {
      const gaw = db.prepare('SELECT * FROM giveaways WHERE message_id = ?').get(msg.id);
      if (!gaw) return;

      const jaEntrou = db.prepare('SELECT * FROM giveaway_participantes WHERE giveaway_id = ? AND user_id = ?').get(gaw.id, i.user.id);
      if (jaEntrou) {
        return i.reply({ content: '🎟️ Você já está participando!', ephemeral: true });
      }

      db.prepare('INSERT INTO giveaway_participantes (giveaway_id, user_id) VALUES (?, ?)').run(gaw.id, i.user.id);
      const total = db.prepare('SELECT COUNT(*) as c FROM giveaway_participantes WHERE giveaway_id = ?').get(gaw.id).c;

      const novoEmbed = EmbedBuilder.from(msg.embeds[0]).setDescription(
        `**Prêmio:** ${premio}${auraPremi > 0 ? `\n**Aura:** ✨ ${auraPremi.toLocaleString('pt-BR')}` : ''}\n\n` +
        `Clique em 🎉 para participar!\n\n` +
        `⏰ Termina: <t:${terminaTS}:R>\n` +
        `🏆 Vencedores: **${vencedores}**\n` +
        `👥 Participantes: **${total}**`
      );

      await msg.edit({ embeds: [novoEmbed] });
      await i.reply({ content: `✅ Você entrou no giveaway! Boa sorte! 🍀`, ephemeral: true });
    });

    collector.on('end', async () => {
      const gaw = db.prepare('SELECT * FROM giveaways WHERE message_id = ?').get(msg.id);
      if (!gaw) return;

      db.prepare('UPDATE giveaways SET ativo = 0 WHERE id = ?').run(gaw.id);
      const participantes = db.prepare('SELECT user_id FROM giveaway_participantes WHERE giveaway_id = ?').all(gaw.id);

      const disabledRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('giveaway_encerrado').setLabel('🎉 Encerrado').setStyle(ButtonStyle.Secondary).setDisabled(true),
      );

      if (!participantes.length) {
        const embedFim = EmbedBuilder.from(msg.embeds[0])
          .setColor('#808080')
          .setTitle('🎁 GIVEAWAY ENCERRADO')
          .setDescription(`**Prêmio:** ${premio}\n\n❌ Ninguém participou...`);
        return msg.edit({ embeds: [embedFim], components: [disabledRow] });
      }

      // Sorteia vencedores
      const shuffled = participantes.sort(() => Math.random() - 0.5);
      const winners = shuffled.slice(0, Math.min(vencedores, participantes.length));
      const winnersMention = winners.map(w => `<@${w.user_id}>`).join(', ');

      if (auraPremi > 0) {
        const { addAura, getUser } = require('../../database/db');
        for (const w of winners) {
          getUser(w.user_id);
          addAura(w.user_id, auraPremi);
        }
      }

      const embedFim = EmbedBuilder.from(msg.embeds[0])
        .setColor('#00C851')
        .setTitle('🎊 GIVEAWAY ENCERRADO!')
        .setDescription(
          `**Prêmio:** ${premio}${auraPremi > 0 ? `\n**Aura:** ✨ ${auraPremi.toLocaleString('pt-BR')}` : ''}\n\n` +
          `🏆 **${winners.length > 1 ? 'Vencedores' : 'Vencedor'}:** ${winnersMention}\n` +
          `👥 **Participantes:** ${participantes.length}`
        );

      await msg.edit({ embeds: [embedFim], components: [disabledRow] });
      await interaction.channel.send(`🎊 Parabéns ${winnersMention}! Você(s) ganhou(ganharam) **${premio}**!${auraPremi > 0 ? ` (+${auraPremi} ✨ Aura)` : ''}`);
    });
  },
};
