const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const meme = {
  data: new SlashCommandBuilder()
    .setName('meme')
    .setDescription('😂 Meme aleatório do Reddit!'),

  async execute(interaction) {
    await interaction.deferReply();
    try {
      const subreddits = ['memes', 'dankmemes', 'ProgrammerHumor', 'AdviceAnimals'];
      const sub = subreddits[Math.floor(Math.random() * subreddits.length)];
      const res = await axios.get(`https://meme-api.com/gimme/${sub}`, { timeout: 5000 });
      const data = res.data;

      const embed = new EmbedBuilder()
        .setColor('#FF6B35')
        .setTitle(data.title.slice(0, 256))
        .setImage(data.url)
        .addFields(
          { name: '👍', value: `${data.ups}`, inline: true },
          { name: '📌 r/', value: data.subreddit, inline: true },
        )
        .setFooter({ text: 'Sentinela Bot • Memes' })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch {
      await interaction.editReply('❌ Não consegui buscar um meme agora. Tenta de novo!');
    }
  },
};

const fatos = [
  'Um caracol pode dormir por até 3 anos seguidos.',
  'As abelhas podem reconhecer rostos humanos.',
  'O coração de uma balestra bate apenas 2 vezes por minuto.',
  'Os polvos têm 3 corações e sangue azul.',
  'A língua de uma baleia azul pesa tanto quanto um elefante.',
  'Formigas nunca dormem.',
  'Um dia em Vênus é mais longo que um ano em Vênus.',
  'Os humanos compartilham 60% do DNA com bananas.',
  'Uma nuvem pode pesar mais de 500.000 kg.',
  'Os tubarões são mais velhos que as árvores.',
  'Cleopatra viveu mais perto da invenção do iPhone do que das pirâmides.',
  'É impossível humear e respirar pelo nariz ao mesmo tempo.',
  'O mel nunca estraga. Mel com 3.000 anos ainda pode ser comido.',
  'O olho humano pode distinguir cerca de 10 milhões de cores diferentes.',
  'Um pulso de raio dura menos de um segundo.',
];

const fato = {
  data: new SlashCommandBuilder()
    .setName('fato')
    .setDescription('🧠 Fato aleatório curioso!'),

  async execute(interaction) {
    const f = fatos[Math.floor(Math.random() * fatos.length)];
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#4ECDC4')
        .setTitle('🧠 Fato Aleatório')
        .setDescription(f)
        .setFooter({ text: 'Sentinela Bot • Fatos Curiosos' })
        .setTimestamp()],
    });
  },
};

const conselho = {
  data: new SlashCommandBuilder()
    .setName('conselho')
    .setDescription('💡 Receba um conselho aleatório'),

  async execute(interaction) {
    await interaction.deferReply();
    try {
      const res = await axios.get('https://api.adviceslip.com/advice', { timeout: 3000 });
      const texto = res.data.slip.advice;

      await interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor('#FFD700')
          .setTitle('💡 Conselho do Dia')
          .setDescription(`*"${texto}"*`)
          .setFooter({ text: 'Sentinela Bot • Conselho' })
          .setTimestamp()],
      });
    } catch {
      await interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor('#FFD700')
          .setTitle('💡 Conselho do Dia')
          .setDescription('*"Beba água, durma bem e seja gentil com as pessoas."*')
          .setFooter({ text: 'Sentinela Bot • Conselho' })],
      });
    }
  },
};

module.exports = [meme, fato, conselho];
