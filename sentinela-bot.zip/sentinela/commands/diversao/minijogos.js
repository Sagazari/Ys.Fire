const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// ─── /8ball ───────────────────────────────────────────────
const bola8 = {
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('🎱 Consulte a Bola Mágica!')
    .addStringOption(opt => opt.setName('pergunta').setDescription('Sua pergunta').setRequired(true)),

  async execute(interaction) {
    const pergunta = interaction.options.getString('pergunta');
    const respostas = [
      { texto: 'Com certeza! ✅', cor: '#00C851' },
      { texto: 'É decidido! ✅', cor: '#00C851' },
      { texto: 'Sem dúvida! ✅', cor: '#00C851' },
      { texto: 'Sim, definitivamente! ✅', cor: '#00C851' },
      { texto: 'Pode contar com isso! ✅', cor: '#00C851' },
      { texto: 'Muito provável! 🟡', cor: '#FFD700' },
      { texto: 'As perspectivas são boas! 🟡', cor: '#FFD700' },
      { texto: 'Sinais apontam que sim 🟡', cor: '#FFD700' },
      { texto: 'Não sei, tente novamente 🟠', cor: '#FFA500' },
      { texto: 'Melhor não te contar agora 🟠', cor: '#FFA500' },
      { texto: 'Não conte com isso ❌', cor: '#FF6B6B' },
      { texto: 'Minha resposta é não ❌', cor: '#FF6B6B' },
      { texto: 'Perspectivas não são boas ❌', cor: '#FF6B6B' },
      { texto: 'Muito duvidoso ❌', cor: '#FF6B6B' },
    ];
    const r = respostas[Math.floor(Math.random() * respostas.length)];

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(r.cor)
        .setTitle('🎱 Bola Mágica')
        .addFields(
          { name: '❓ Pergunta', value: pergunta },
          { name: '🎱 Resposta', value: r.texto }
        )
        .setFooter({ text: 'Sentinela Bot • 8Ball' })],
    });
  },
};

// ─── /coinflip ────────────────────────────────────────────
const coinflip = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('🪙 Cara ou Coroa?'),

  async execute(interaction) {
    const resultado = Math.random() < 0.5 ? 'Cara 👤' : 'Coroa 👑';
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('🪙 Cara ou Coroa?')
        .setDescription(`A moeda girou e... **${resultado}**!`)
        .setFooter({ text: 'Sentinela Bot • Coinflip' })],
    });
  },
};

// ─── /dado ────────────────────────────────────────────────
const dado = {
  data: new SlashCommandBuilder()
    .setName('dado')
    .setDescription('🎲 Role um dado!')
    .addIntegerOption(opt =>
      opt.setName('lados').setDescription('Número de lados (padrão: 6)').setRequired(false).setMinValue(2).setMaxValue(1000)
    ),

  async execute(interaction) {
    const lados = interaction.options.getInteger('lados') || 6;
    const resultado = Math.floor(Math.random() * lados) + 1;
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#7B2FBE')
        .setTitle('🎲 Dado Rolado!')
        .setDescription(`D${lados} → **${resultado}**`)
        .setFooter({ text: `Sentinela Bot • Dado de ${lados} lados` })],
    });
  },
};

// ─── /rps ────────────────────────────────────────────────
const rps = {
  data: new SlashCommandBuilder()
    .setName('rps')
    .setDescription('✊ Pedra, Papel ou Tesoura!')
    .addStringOption(opt =>
      opt.setName('escolha')
        .setDescription('Sua escolha')
        .setRequired(true)
        .addChoices(
          { name: '✊ Pedra', value: 'pedra' },
          { name: '🖐️ Papel', value: 'papel' },
          { name: '✌️ Tesoura', value: 'tesoura' },
        )
    ),

  async execute(interaction) {
    const jogadas = ['pedra', 'papel', 'tesoura'];
    const emojis = { pedra: '✊', papel: '🖐️', tesoura: '✌️' };
    const jogador = interaction.options.getString('escolha');
    const bot = jogadas[Math.floor(Math.random() * 3)];

    let resultado, cor;
    if (jogador === bot) { resultado = '🤝 Empate!'; cor = '#FFD700'; }
    else if (
      (jogador === 'pedra' && bot === 'tesoura') ||
      (jogador === 'papel' && bot === 'pedra') ||
      (jogador === 'tesoura' && bot === 'papel')
    ) { resultado = '🎉 Você venceu!'; cor = '#00C851'; }
    else { resultado = '😢 Você perdeu!'; cor = '#FF6B6B'; }

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(cor)
        .setTitle('✊ Pedra, Papel ou Tesoura!')
        .addFields(
          { name: '👤 Você', value: `${emojis[jogador]} ${jogador}`, inline: true },
          { name: '🤖 Sentinela', value: `${emojis[bot]} ${bot}`, inline: true },
          { name: '🏆 Resultado', value: resultado, inline: false },
        )
        .setFooter({ text: 'Sentinela Bot • RPS' })],
    });
  },
};

// ─── /verdade ────────────────────────────────────────────
const verdades = [
  'Qual foi a coisa mais estranha que você já fez?',
  'Qual é o seu maior medo?',
  'Você já mentiu para um amigo próximo? Sobre o quê?',
  'Qual é o seu guilty pleasure secreto?',
  'Você já ficou com alguém que não devia?',
  'Qual é a pior coisa que você já fez e não contou pra ninguém?',
  'Você já teve um crush em alguém do servidor?',
  'Qual foi sua maior mamada em jogo?',
  'Você já chorou com um filme/série?',
  'Qual é a sua maior vergonha online?',
];

const desafios = [
  'Mande uma mensagem constrangedora para alguém aleatório do servidor!',
  'Imite o último meme que você enviou no chat.',
  'Escreva um poema de 4 linhas sobre o próximo membro a falar.',
  'Mande uma foto com um chapéu improvisado de papel.',
  'Fale em rima pelas próximas 3 mensagens.',
  'Elogie cada membro do VC de uma forma engraçada.',
  'Imite um pokémon por 1 minuto.',
  'Mude seu nick para algo ridículo por 10 minutos.',
  'Diga um segredo de jogador que você nunca contou.',
  'Cante um trecho de qualquer música no VC.',
];

const verdadeOuDesafio = {
  data: new SlashCommandBuilder()
    .setName('vod')
    .setDescription('🎭 Verdade ou Desafio!')
    .addStringOption(opt =>
      opt.setName('tipo')
        .setDescription('Escolha')
        .setRequired(false)
        .addChoices(
          { name: '🤔 Verdade', value: 'verdade' },
          { name: '💪 Desafio', value: 'desafio' },
        )
    ),

  async execute(interaction) {
    const tipo = interaction.options.getString('tipo') || (Math.random() < 0.5 ? 'verdade' : 'desafio');
    const lista = tipo === 'verdade' ? verdades : desafios;
    const item = lista[Math.floor(Math.random() * lista.length)];
    const cor = tipo === 'verdade' ? '#4ECDC4' : '#FF6B6B';
    const emoji = tipo === 'verdade' ? '🤔' : '💪';

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(cor)
        .setTitle(`${emoji} ${tipo === 'verdade' ? 'Verdade' : 'Desafio'}!`)
        .setDescription(item)
        .setFooter({ text: `Sentinela Bot • VoD • ${interaction.user.username}` })
        .setTimestamp()],
    });
  },
};

// ─── /escolher ───────────────────────────────────────────
const escolher = {
  data: new SlashCommandBuilder()
    .setName('escolher')
    .setDescription('🤔 Deixa o Sentinela escolher por você!')
    .addStringOption(opt =>
      opt.setName('opcoes').setDescription('Opções separadas por vírgula. Ex: pizza, hamburguer, sushi').setRequired(true)
    ),

  async execute(interaction) {
    const input = interaction.options.getString('opcoes');
    const opcoes = input.split(',').map(o => o.trim()).filter(Boolean);

    if (opcoes.length < 2) {
      return interaction.reply({ content: '❌ Coloque pelo menos 2 opções separadas por vírgula!', ephemeral: true });
    }

    const escolha = opcoes[Math.floor(Math.random() * opcoes.length)];

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#7B2FBE')
        .setTitle('🤔 A decisão foi tomada!')
        .setDescription(`**${escolha}** 🎯`)
        .addFields({ name: 'Opções', value: opcoes.join(', ') })
        .setFooter({ text: 'Sentinela Bot • Escolher' })],
    });
  },
};

// ─── /pp ─────────────────────────────────────────────────
const pp = {
  data: new SlashCommandBuilder()
    .setName('pp')
    .setDescription('📏 Medidor de... habilidades 😏')
    .addUserOption(opt => opt.setName('usuario').setDescription('Usuário').setRequired(false)),

  async execute(interaction) {
    const alvo = interaction.options.getUser('usuario') || interaction.user;
    const seed = BigInt(alvo.id) % 21n;
    const tamanho = Number(seed);
    const barra = '█'.repeat(tamanho) + '░'.repeat(20 - tamanho);

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#FF69B4')
        .setTitle('📏 Medidor de Habilidades')
        .setDescription(`**${alvo.username}** tem...\n\n8${barra}D\n\n**${tamanho} cm** de talento!`)
        .setFooter({ text: 'Sentinela Bot • Totalmente científico 😏' })],
    });
  },
};

// ─── /gay ─────────────────────────────────────────────────
const gay = {
  data: new SlashCommandBuilder()
    .setName('gay')
    .setDescription('🏳️‍🌈 Medidor de gay-ness!')
    .addUserOption(opt => opt.setName('usuario').setDescription('Usuário').setRequired(false)),

  async execute(interaction) {
    const alvo = interaction.options.getUser('usuario') || interaction.user;
    const seed = Number(BigInt(alvo.id) % 101n);
    const barra = Math.floor(seed / 10);
    const progressBar = '🏳️‍🌈'.repeat(barra) + '⬛'.repeat(10 - barra);

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#FF69B4')
        .setTitle('🏳️‍🌈 Medidor de Gay-ness')
        .setDescription(`${alvo} é **${seed}%** gay!\n\n${progressBar}`)
        .setFooter({ text: 'Sentinela Bot • Por diversão apenas! 🌈' })],
    });
  },
};

// ─── /amogus ─────────────────────────────────────────────
const amogus = {
  data: new SlashCommandBuilder()
    .setName('impostora')
    .setDescription('🔴 Quem é o/a impostor(a)?')
    .addUserOption(opt => opt.setName('usuario').setDescription('Suspeito(a)').setRequired(false)),

  async execute(interaction) {
    const alvo = interaction.options.getUser('usuario') || interaction.user;
    const impostor = Math.random() < 0.5;

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(impostor ? '#FF0000' : '#00C851')
        .setTitle('🔴 Among Us')
        .setDescription(impostor
          ? `${alvo} **É O/A IMPOSTOR(A)!** 🔴\n\n*sus sus sus sus*`
          : `${alvo} **é inocente!** ✅\n\n*Parece confiável... ou será que não?*`)
        .setFooter({ text: 'Sentinela Bot • Ejete o impostor!' })],
    });
  },
};

module.exports = [bola8, coinflip, dado, rps, verdadeOuDesafio, escolher, pp, gay, amogus];
