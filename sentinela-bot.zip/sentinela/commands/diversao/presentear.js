const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, removeItem, addItem, hasItem } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('presentear')
    .setDescription('🎁 Presenteie alguém com um item do inventário')
    .addUserOption(opt => opt.setName('usuario').setDescription('Para quem?').setRequired(true))
    .addStringOption(opt => opt.setName('item').setDescription('Nome do item').setRequired(true)),

  async execute(interaction) {
    const alvo = interaction.options.getUser('usuario');
    const item = interaction.options.getString('item');

    if (alvo.id === interaction.user.id) return interaction.reply({ content: '🤦 Você não pode se dar presente!', ephemeral: true });
    if (alvo.bot) return interaction.reply({ content: '🤖 Bots não aceitam presentes.', ephemeral: true });

    if (!hasItem(interaction.user.id, item)) {
      return interaction.reply({
        content: `❌ Você não tem **${item}** no inventário!`,
        ephemeral: true,
      });
    }

    getUser(alvo.id, alvo.username);
    removeItem(interaction.user.id, item);
    addItem(alvo.id, item);

    const db = require('../../database/db').db;
    const shopItem = db.prepare('SELECT emoji FROM shop WHERE LOWER(nome) = LOWER(?)').get(item);
    const emoji = shopItem?.emoji || '🎁';

    const embed = new EmbedBuilder()
      .setColor('#FF69B4')
      .setTitle('🎁 Presente enviado!')
      .setDescription(`${interaction.user} deu **${emoji} ${item}** para ${alvo}!\n\nQue presente charmoso! 💕`)
      .setFooter({ text: 'Sentinela Bot • Presente' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
