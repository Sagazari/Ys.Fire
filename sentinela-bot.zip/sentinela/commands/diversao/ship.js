const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ship')
    .setDescription('💘 Dê ship em duas pessoas!')
    .addUserOption(opt => opt.setName('pessoa1').setDescription('Primeira pessoa').setRequired(true))
    .addUserOption(opt => opt.setName('pessoa2').setDescription('Segunda pessoa (padrão: você)').setRequired(false)),

  async execute(interaction) {
    const p1 = interaction.options.getUser('pessoa1');
    const p2 = interaction.options.getUser('pessoa2') || interaction.user;

    // Seed baseado nos IDs para resultado consistente
    const seed = (BigInt(p1.id) + BigInt(p2.id)) % 101n;
    const porcentagem = Number(seed);

    const barra = Math.floor(porcentagem / 10);
    const progressBar = '❤️'.repeat(barra) + '🖤'.repeat(10 - barra);

    let nivel, cor, emoji;
    if (porcentagem >= 90) { nivel = 'Almas gêmeas!'; cor = '#FF1493'; emoji = '💞'; }
    else if (porcentagem >= 75) { nivel = 'Muito compatíveis!'; cor = '#FF69B4'; emoji = '💕'; }
    else if (porcentagem >= 60) { nivel = 'Boa química!'; cor = '#FF6B6B'; emoji = '💗'; }
    else if (porcentagem >= 40) { nivel = 'Pode dar certo!'; cor = '#FFD700'; emoji = '💛'; }
    else if (porcentagem >= 20) { nivel = 'Hmm... talvez?'; cor = '#FFA500'; emoji = '🧡'; }
    else { nivel = 'Melhor como amigos 😅'; cor = '#808080'; emoji = '💔'; }

    // Nome do casal
    const n1 = p1.username.slice(0, Math.ceil(p1.username.length / 2));
    const n2 = p2.username.slice(Math.floor(p2.username.length / 2));
    const nomeShip = n1 + n2;

    const embed = new EmbedBuilder()
      .setColor(cor)
      .setTitle(`${emoji} Ship: ${nomeShip}`)
      .setDescription(`${p1} **+** ${p2}`)
      .addFields(
        { name: '💘 Compatibilidade', value: `${progressBar} **${porcentagem}%**`, inline: false },
        { name: '💬 Veredicto', value: nivel, inline: false }
      )
      .setFooter({ text: 'Sentinela Bot • Ship' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
