const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, removeAura, addItem, addAura } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('comprar')
    .setDescription('💳 Compre um item da loja')
    .addStringOption(opt =>
      opt.setName('item').setDescription('Nome do item').setRequired(true)
    ),

  async execute(interaction) {
    const nomeItem = interaction.options.getString('item');
    const db = require('../../database/db').db;
    const item = db.prepare('SELECT * FROM shop WHERE LOWER(nome) = LOWER(?) AND ativo = 1').get(nomeItem);

    if (!item) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('❌ Item não encontrado!')
          .setDescription(`Use **/loja** para ver os itens disponíveis.`)],
        ephemeral: true,
      });
    }

    const user = getUser(interaction.user.id, interaction.user.username);
    if (user.aura < item.preco) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('❌ Aura insuficiente!')
          .setDescription(`Você precisa de **${item.preco.toLocaleString('pt-BR')} ✨** mas tem apenas **${user.aura.toLocaleString('pt-BR')} ✨**.`)],
        ephemeral: true,
      });
    }

    removeAura(interaction.user.id, item.preco);

    // Efeito imediato do Elixir de Aura
    if (item.nome === 'Elixir de Aura') {
      addAura(interaction.user.id, 1000);
    } else {
      addItem(interaction.user.id, item.nome);
    }

    const embed = new EmbedBuilder()
      .setColor('#00C851')
      .setTitle(`${item.emoji} Compra realizada!`)
      .setDescription(`Você comprou **${item.nome}** por **${item.preco.toLocaleString('pt-BR')} ✨ Aura**!`)
      .setFooter({ text: item.nome === 'Elixir de Aura' ? '✨ +1000 Aura adicionados!' : 'Item adicionado ao seu inventário!' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
