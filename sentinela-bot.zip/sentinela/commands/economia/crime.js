const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, addAura, removeAura, addXP, hasItem } = require('../../database/db');

const crimes = [
  { nome: 'Hackeou o banco central', emoji: '💻', ganhoMin: 500, ganhoMax: 1500 },
  { nome: 'Roubou uma loja de eletrônicos', emoji: '📱', ganhoMin: 200, ganhoMax: 700 },
  { nome: 'Falsificou documentos', emoji: '📄', ganhoMin: 150, ganhoMax: 500 },
  { nome: 'Contrabandeou memes raros', emoji: '😂', ganhoMin: 100, ganhoMax: 400 },
  { nome: 'Assaltou uma padaria', emoji: '🥐', ganhoMin: 50, ganhoMax: 200 },
  { nome: 'Roubou o Wi-Fi do vizinho', emoji: '📶', ganhoMin: 30, ganhoMax: 100 },
  { nome: 'Pirou o carro do chefe', emoji: '🚗', ganhoMin: 300, ganhoMax: 800 },
  { nome: 'Vendeu segredos da NASA', emoji: '🚀', ganhoMin: 800, ganhoMax: 2000 },
];

const falhas = [
  'Você escorregou na casca de banana ao fugir 🍌',
  'A câmera de segurança te filmou dançando antes do crime 📸',
  'Você esqueceu a carteira no local do crime 👛',
  'O cachorro da vítima te mordeu antes de chegar perto 🐕',
  'Você foi reconhecido por ser famoso no Discord 😭',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('crime')
    .setDescription('🦹 Tente a sorte no crime (arriscado!)'),

  async execute(interaction) {
    const user = getUser(interaction.user.id, interaction.user.username);
    const agora = new Date();
    const ultimo = user.last_crime ? new Date(user.last_crime) : null;
    const cooldown = 2 * 60 * 60 * 1000; // 2 horas

    if (ultimo && agora - ultimo < cooldown) {
      const restante = new Date(ultimo.getTime() + cooldown - agora);
      const horas = Math.floor(restante / 3600000);
      const minutos = Math.floor((restante % 3600000) / 60000);

      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('🚓 A polícia ainda está te procurando!')
          .setDescription(`Espere **${horas}h ${minutos}m** antes de tentar de novo.`)
          .setFooter({ text: 'Sentinela Bot • Crime' })],
      });
    }

    const temCapa = hasItem(interaction.user.id, 'Capa do Ladrão');
    const chanceSuccess = temCapa ? 0.65 : 0.50;
    const sucesso = Math.random() < chanceSuccess;
    const crime = crimes[Math.floor(Math.random() * crimes.length)];

    const db = require('../../database/db').db;
    db.prepare('UPDATE usuarios SET last_crime = ? WHERE id = ?').run(agora.toISOString(), interaction.user.id);

    if (sucesso) {
      const ganho = Math.floor(Math.random() * (crime.ganhoMax - crime.ganhoMin + 1)) + crime.ganhoMin;
      addAura(interaction.user.id, ganho);
      addXP(interaction.user.id, 75);

      const embed = new EmbedBuilder()
        .setColor('#00C851')
        .setTitle(`${crime.emoji} Crime bem-sucedido!`)
        .setDescription(`Você **${crime.nome}** e ninguém te viu!\n\n💰 Ganhou **+${ganho.toLocaleString('pt-BR')} ✨ Aura**!`)
        .setFooter({ text: `Sentinela Bot • Crime${temCapa ? ' • 🥷 Capa ativa' : ''}` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    } else {
      const multa = Math.floor(Math.random() * 300) + 100;
      removeAura(interaction.user.id, multa);
      const falha = falhas[Math.floor(Math.random() * falhas.length)];
      db.prepare('UPDATE usuarios SET mortes = mortes + 1 WHERE id = ?').run(interaction.user.id);

      const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('🚔 Você foi preso!')
        .setDescription(`${falha}\n\nPagou **-${multa} ✨ Aura** de fiança.`)
        .setFooter({ text: 'Sentinela Bot • Crime' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
