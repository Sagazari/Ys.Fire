const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, addAura, addXP, hasItem } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('🌟 Colete sua Aura diária!'),

  async execute(interaction) {
    const user = getUser(interaction.user.id, interaction.user.username);
    const agora = new Date();
    const ultimo = user.last_daily ? new Date(user.last_daily) : null;
    const cooldown = 20 * 60 * 60 * 1000; // 20 horas

    if (ultimo && agora - ultimo < cooldown) {
      const restante = new Date(ultimo.getTime() + cooldown - agora);
      const horas = Math.floor(restante / 3600000);
      const minutos = Math.floor((restante % 3600000) / 60000);

      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('⏰ Calma aí, guerreiro!')
        .setDescription(`Você já coletou sua Aura hoje.\nVolte em **${horas}h ${minutos}m**.`)
        .setThumbnail(interaction.user.displayAvatarURL())
        .setFooter({ text: 'Sentinela Bot • Daily' });

      return interaction.reply({ embeds: [embed] });
    }

    // Calcula Aura base + streak bonus
    const temAmuleto = hasItem(interaction.user.id, 'Amuleto da Sorte');
    let auraBase = Math.floor(Math.random() * 500) + 750; // 750~1250
    if (temAmuleto) auraBase *= 2;

    const bonus = Math.random() < 0.1 ? Math.floor(Math.random() * 500) + 200 : 0;
    const total = auraBase + bonus;

    addAura(interaction.user.id, total);
    const { levelUp, novoNivel } = addXP(interaction.user.id, 100);

    const db = require('../../database/db').db;
    db.prepare('UPDATE usuarios SET last_daily = ? WHERE id = ?').run(agora.toISOString(), interaction.user.id);

    const userAtualizado = getUser(interaction.user.id);

    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle('✨ Aura Coletada!')
      .setDescription(`${interaction.user}, você coletou sua Aura do dia!`)
      .addFields(
        { name: '✨ Aura Recebida', value: `**+${total.toLocaleString('pt-BR')}**${bonus > 0 ? ` (🎉 Bônus: +${bonus})` : ''}`, inline: true },
        { name: '💰 Aura Total', value: `**${userAtualizado.aura.toLocaleString('pt-BR')}**`, inline: true },
        { name: '⭐ XP Ganho', value: `**+100 XP**${levelUp ? ` → Nível **${novoNivel}**! 🎊` : ''}`, inline: true }
      )
      .setThumbnail(interaction.user.displayAvatarURL())
      .setFooter({ text: temAmuleto ? '🍀 Amuleto da Sorte ativo!' : 'Sentinela Bot • Daily' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
