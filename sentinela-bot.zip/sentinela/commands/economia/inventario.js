const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getInventario } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inventario')
    .setDescription('🎒 Veja seu inventário'),

  async execute(interaction) {
    const inv = getInventario(interaction.user.id);

    const embed = new EmbedBuilder()
      .setColor('#7B2FBE')
      .setTitle(`🎒 Inventário de ${interaction.user.username}`)
      .setThumbnail(interaction.user.displayAvatarURL());

    if (!inv.length) {
      embed.setDescription('Seu inventário está vazio!\nCompre itens na **/loja**.');
    } else {
      const db = require('../../database/db').db;
      const linhas = inv.map(i => {
        const shopItem = db.prepare('SELECT emoji FROM shop WHERE nome = ?').get(i.item);
        const emoji = shopItem?.emoji || '📦';
        return `${emoji} **${i.item}** x${i.quantidade}`;
      }).join('\n');
      embed.setDescription(linhas);
    }

    embed.setFooter({ text: 'Sentinela Bot • Inventário' }).setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
