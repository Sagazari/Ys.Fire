const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, removeAura, addItem, addAura } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loja')
    .setDescription('🛒 Veja os itens disponíveis na loja'),

  async execute(interaction) {
    const db = require('../../database/db').db;
    const itens = db.prepare('SELECT * FROM shop WHERE ativo = 1').all();

    const linhas = itens.map(item =>
      `${item.emoji} **${item.nome}** — \`${item.preco.toLocaleString('pt-BR')} ✨\`\n> ${item.descricao}`
    ).join('\n\n');

    const user = getUser(interaction.user.id);

    const embed = new EmbedBuilder()
      .setColor('#7B2FBE')
      .setTitle('🛒 Loja da Aura')
      .setDescription(linhas)
      .addFields({ name: '💰 Sua Aura', value: `**${user.aura.toLocaleString('pt-BR')}**`, inline: true })
      .setFooter({ text: 'Use /comprar <item> para adquirir • Sentinela Bot' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
