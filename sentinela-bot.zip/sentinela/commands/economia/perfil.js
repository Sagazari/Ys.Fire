const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('perfil')
    .setDescription('👤 Veja seu perfil ou de outro usuário')
    .addUserOption(opt =>
      opt.setName('usuario').setDescription('Usuário para ver o perfil').setRequired(false)
    ),

  async execute(interaction) {
    const alvo = interaction.options.getUser('usuario') || interaction.user;
    const user = getUser(alvo.id, alvo.username);

    const xpNecessario = user.nivel * 500;
    const barraXP = Math.floor((user.xp / xpNecessario) * 10);
    const barra = '█'.repeat(barraXP) + '░'.repeat(10 - barraXP);

    const casado = user.casado_com
      ? `💒 Casado(a) com <@${user.casado_com}>`
      : '💔 Solteiro(a)';

    const medalha =
      user.nivel >= 50 ? '👑' :
      user.nivel >= 30 ? '💎' :
      user.nivel >= 20 ? '🥇' :
      user.nivel >= 10 ? '🥈' : '🥉';

    const embed = new EmbedBuilder()
      .setColor('#7B2FBE')
      .setTitle(`${medalha} Perfil de ${alvo.username}`)
      .setThumbnail(alvo.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: '✨ Aura', value: `**${user.aura.toLocaleString('pt-BR')}**`, inline: true },
        { name: '🏆 Aura Total', value: `**${user.aura_total.toLocaleString('pt-BR')}**`, inline: true },
        { name: '⭐ Nível', value: `**${user.nivel}**`, inline: true },
        { name: `📊 XP [${barra}]`, value: `${user.xp} / ${xpNecessario}`, inline: false },
        { name: '💍 Status', value: casado, inline: false },
      )
      .setFooter({ text: 'Sentinela Bot • Perfil' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
