const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRanking } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ranking')
    .setDescription('🏆 Veja o top 10 de Aura do servidor'),

  async execute(interaction) {
    await interaction.deferReply();
    const top = getRanking(10);

    if (!top.length) {
      return interaction.editReply('Nenhum usuário registrado ainda!');
    }

    const medalhas = ['🥇', '🥈', '🥉'];
    const linhas = await Promise.all(top.map(async (u, i) => {
      let nome;
      try {
        const member = await interaction.guild.members.fetch(u.id).catch(() => null);
        nome = member ? member.displayName : u.username || 'Usuário';
      } catch {
        nome = u.username || 'Usuário';
      }
      const medal = medalhas[i] || `**${i + 1}.**`;
      return `${medal} **${nome}** — ✨ ${u.aura.toLocaleString('pt-BR')} Aura`;
    }));

    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle('🏆 Ranking de Aura')
      .setDescription(linhas.join('\n'))
      .setFooter({ text: 'Sentinela Bot • Top 10' })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};
