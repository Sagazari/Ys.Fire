const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, addAura, removeAura, hasItem } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roubar')
    .setDescription('🥷 Tente roubar a Aura de alguém')
    .addUserOption(opt =>
      opt.setName('alvo').setDescription('Quem você quer roubar').setRequired(true)
    ),

  async execute(interaction) {
    const alvo = interaction.options.getUser('alvo');

    if (alvo.id === interaction.user.id) {
      return interaction.reply({ content: '🤦 Você não pode se roubar!', ephemeral: true });
    }
    if (alvo.bot) {
      return interaction.reply({ content: '🤖 Roubar bot? Sério?', ephemeral: true });
    }

    const user = getUser(interaction.user.id, interaction.user.username);
    const vitima = getUser(alvo.id, alvo.username);
    const agora = new Date();
    const ultimo = user.last_roubo ? new Date(user.last_roubo) : null;
    const cooldown = 3 * 60 * 60 * 1000; // 3 horas

    if (ultimo && agora - ultimo < cooldown) {
      const restante = new Date(ultimo.getTime() + cooldown - agora);
      const horas = Math.floor(restante / 3600000);
      const minutos = Math.floor((restante % 3600000) / 60000);
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('⏰ Cooldown de Roubo')
          .setDescription(`Espere **${horas}h ${minutos}m** para roubar novamente.`)],
      });
    }

    if (vitima.aura < 100) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('😭 Alvo pobre!')
          .setDescription(`${alvo.username} tem menos de 100 Aura. Não vale a pena.`)],
      });
    }

    // Escudo de Aura protege a vítima
    if (hasItem(alvo.id, 'Escudo de Aura')) {
      const db = require('../../database/db').db;
      db.prepare('UPDATE usuarios SET last_roubo = ? WHERE id = ?').run(agora.toISOString(), interaction.user.id);

      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('🛡️ Bloqueado!')
          .setDescription(`${alvo.username} está protegido por um **Escudo de Aura**!\nVocê foi repelido.`)],
      });
    }

    const sucesso = Math.random() < 0.45;
    const db = require('../../database/db').db;
    db.prepare('UPDATE usuarios SET last_roubo = ? WHERE id = ?').run(agora.toISOString(), interaction.user.id);

    if (sucesso) {
      const porcentagem = Math.random() * 0.25 + 0.05; // 5~30%
      const roubado = Math.floor(vitima.aura * porcentagem);
      removeAura(alvo.id, roubado);
      addAura(interaction.user.id, roubado);

      const embed = new EmbedBuilder()
        .setColor('#00C851')
        .setTitle('🥷 Roubo bem-sucedido!')
        .setDescription(`Você roubou **${roubado.toLocaleString('pt-BR')} ✨ Aura** de ${alvo}!`)
        .setFooter({ text: 'Sentinela Bot • Roubo' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    } else {
      const multa = Math.floor(Math.random() * 200) + 100;
      removeAura(interaction.user.id, multa);

      const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('🚨 Flagrado!')
        .setDescription(`${alvo} te pegou no flagra! Você pagou **-${multa} ✨ Aura** de indenização.`)
        .setFooter({ text: 'Sentinela Bot • Roubo' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
