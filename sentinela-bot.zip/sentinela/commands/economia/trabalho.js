const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, addAura, addXP } = require('../../database/db');

const trabalhos = [
  { nome: 'Pizzaiolo', emoji: '🍕', frase: 'Você fez 15 pizzas e recebeu', min: 100, max: 300 },
  { nome: 'Streamer', emoji: '🎮', frase: 'Você ficou ao vivo por 2h e recebeu', min: 150, max: 400 },
  { nome: 'Médico', emoji: '🏥', frase: 'Você salvou 3 vidas hoje e recebeu', min: 200, max: 500 },
  { nome: 'Youtuber', emoji: '📹', frase: 'Seu vídeo viralizou e você recebeu', min: 200, max: 600 },
  { nome: 'Programador', emoji: '💻', frase: 'Você consertou um bug crítico e recebeu', min: 250, max: 550 },
  { nome: 'Cantor', emoji: '🎤', frase: 'Você se apresentou num show e recebeu', min: 200, max: 500 },
  { nome: 'Chef', emoji: '👨‍🍳', frase: 'Você preparou um banquete e recebeu', min: 150, max: 350 },
  { nome: 'Astronauta', emoji: '🚀', frase: 'Você viajou ao espaço e recebeu', min: 300, max: 700 },
  { nome: 'Detetive', emoji: '🕵️', frase: 'Você resolveu um crime e recebeu', min: 200, max: 500 },
  { nome: 'Surfista', emoji: '🏄', frase: 'Você ganhou um campeonato e recebeu', min: 180, max: 450 },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('trabalho')
    .setDescription('💼 Trabalhe para ganhar Aura'),

  async execute(interaction) {
    const user = getUser(interaction.user.id, interaction.user.username);
    const agora = new Date();
    const ultimo = user.last_trabalho ? new Date(user.last_trabalho) : null;
    const cooldown = 60 * 60 * 1000; // 1 hora

    if (ultimo && agora - ultimo < cooldown) {
      const restante = new Date(ultimo.getTime() + cooldown - agora);
      const minutos = Math.floor(restante / 60000);
      const segundos = Math.floor((restante % 60000) / 1000);

      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('⏰ Você está cansado!')
          .setDescription(`Descanse um pouco. Pode trabalhar em **${minutos}m ${segundos}s**.`)
          .setFooter({ text: 'Sentinela Bot • Trabalho' })],
      });
    }

    const trabalho = trabalhos[Math.floor(Math.random() * trabalhos.length)];
    const ganho = Math.floor(Math.random() * (trabalho.max - trabalho.min + 1)) + trabalho.min;

    addAura(interaction.user.id, ganho);
    addXP(interaction.user.id, 50);

    const db = require('../../database/db').db;
    db.prepare('UPDATE usuarios SET last_trabalho = ? WHERE id = ?').run(agora.toISOString(), interaction.user.id);

    const embed = new EmbedBuilder()
      .setColor('#00C851')
      .setTitle(`${trabalho.emoji} Trabalho: ${trabalho.nome}`)
      .setDescription(`${trabalho.frase} **+${ganho.toLocaleString('pt-BR')} ✨ Aura**!`)
      .addFields({ name: '⭐ XP', value: '+50 XP', inline: true })
      .setFooter({ text: 'Sentinela Bot • Trabalho • Cooldown: 1h' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
