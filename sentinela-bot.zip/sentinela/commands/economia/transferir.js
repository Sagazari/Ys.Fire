const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, addAura, removeAura } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('transferir')
    .setDescription('💸 Transfira Aura para outro usuário')
    .addUserOption(opt =>
      opt.setName('usuario').setDescription('Quem vai receber').setRequired(true)
    )
    .addIntegerOption(opt =>
      opt.setName('quantidade').setDescription('Quanto transferir').setRequired(true).setMinValue(1)
    ),

  async execute(interaction) {
    const alvo = interaction.options.getUser('usuario');
    const quantidade = interaction.options.getInteger('quantidade');

    if (alvo.id === interaction.user.id) return interaction.reply({ content: '🤦 Você não pode transferir para si mesmo!', ephemeral: true });
    if (alvo.bot) return interaction.reply({ content: '🤖 Bots não aceitam Aura.', ephemeral: true });

    const user = getUser(interaction.user.id, interaction.user.username);

    if (user.aura < quantidade) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('❌ Aura insuficiente!')
          .setDescription(`Você tem apenas **${user.aura.toLocaleString('pt-BR')} ✨ Aura**.`)],
      });
    }

    getUser(alvo.id, alvo.username);
    removeAura(interaction.user.id, quantidade);
    addAura(alvo.id, quantidade);

    const embed = new EmbedBuilder()
      .setColor('#7B2FBE')
      .setTitle('💸 Transferência realizada!')
      .setDescription(`**${interaction.user.username}** enviou **${quantidade.toLocaleString('pt-BR')} ✨ Aura** para ${alvo}!`)
      .setFooter({ text: 'Sentinela Bot • Transferência' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
