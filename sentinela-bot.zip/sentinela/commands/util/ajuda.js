const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ComponentType } = require('discord.js');

const categorias = {
  economia: {
    emoji: '💰',
    nome: 'Economia',
    desc: 'Comandos de Aura e economia',
    comandos: [
      '`/daily` — Colete sua Aura diária',
      '`/trabalho` — Trabalhe para ganhar Aura (CD: 1h)',
      '`/crime` — Tente a sorte no crime (CD: 2h)',
      '`/roubar @user` — Roube a Aura de alguém (CD: 3h)',
      '`/apostar <valor>` — Jogue no caça-níquel',
      '`/transferir @user <valor>` — Transfira Aura',
      '`/perfil [@user]` — Veja seu perfil',
      '`/ranking` — Top 10 de Aura',
      '`/inventario` — Seu inventário',
      '`/loja` — Itens disponíveis',
      '`/comprar <item>` — Compre um item',
    ],
  },
  diversao: {
    emoji: '🎮',
    nome: 'Diversão',
    desc: 'Brincadeiras e entretenimento',
    comandos: [
      '`/ship @p1 [@p2]` — Compatibilidade entre dois usuários',
      '`/casar @user` — Peça alguém em casamento',
      '`/divorciar` — Termine seu casamento',
      '`/duelo @user <aposta>` — Duelo de Aura PvP',
      '`/giveaway` — Crie um sorteio',
      '`/vod [tipo]` — Verdade ou Desafio',
      '`/8ball <pergunta>` — Bola Mágica',
      '`/rps <escolha>` — Pedra, Papel ou Tesoura',
      '`/coinflip` — Cara ou Coroa',
      '`/dado [lados]` — Role um dado',
      '`/pp [@user]` — Medidor 😏',
      '`/gay [@user]` — Medidor 🌈',
      '`/impostora [@user]` — Among Us',
      '`/escolher <opções>` — Decide por você',
      '`/meme` — Meme aleatório',
      '`/fato` — Fato curioso',
      '`/conselho` — Conselho do dia',
    ],
  },
  acoes: {
    emoji: '🥰',
    nome: 'Ações',
    desc: 'Ações com GIFs animados',
    comandos: [
      '`/hug @user` — Abraço',
      '`/kiss @user` — Beijo',
      '`/slap @user` — Tapa',
      '`/pat @user` — Cafuné',
      '`/punch @user` — Soco',
      '`/bite @user` — Mordida',
      '`/cuddle @user` — Aconchego',
      '`/poke @user` — Cutucar',
      '`/highfive @user` — High five',
      '`/wave @user` — Acenar',
      '`/wink @user` — Piscar',
    ],
  },
  util: {
    emoji: '🔧',
    nome: 'Utilidades',
    desc: 'Ferramentas úteis',
    comandos: [
      '`/ping` — Latência do bot',
      '`/avatar [@user]` — Avatar em alta resolução',
      '`/userinfo [@user]` — Info do usuário',
      '`/serverinfo` — Info do servidor',
      '`/enquete <pergunta> <opções>` — Crie uma enquete',
      '`/sortear [min] [max]` — Número aleatório',
      '`/presentear @user <item>` — Presente de inventário',
      '`/say <mensagem>` — Faz o bot falar',
    ],
  },
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ajuda')
    .setDescription('📖 Lista todos os comandos do Sentinela'),

  async execute(interaction) {
    const mainEmbed = new EmbedBuilder()
      .setColor('#7B2FBE')
      .setTitle('📖 Sentinela — Central de Ajuda')
      .setDescription('Selecione uma categoria abaixo para ver os comandos disponíveis!')
      .addFields(Object.values(categorias).map(c => ({
        name: `${c.emoji} ${c.nome}`,
        value: c.desc,
        inline: true,
      })))
      .setThumbnail(interaction.client.user.displayAvatarURL())
      .setFooter({ text: 'Sentinela Bot • /ajuda' })
      .setTimestamp();

    const menu = new StringSelectMenuBuilder()
      .setCustomId('ajuda_menu')
      .setPlaceholder('📂 Selecione uma categoria...')
      .addOptions(Object.entries(categorias).map(([key, cat]) => ({
        label: cat.nome,
        description: cat.desc,
        value: key,
        emoji: cat.emoji,
      })));

    const row = new ActionRowBuilder().addComponents(menu);
    const msg = await interaction.reply({ embeds: [mainEmbed], components: [row], fetchReply: true });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      filter: i => i.user.id === interaction.user.id,
      time: 120000,
    });

    collector.on('collect', async i => {
      const cat = categorias[i.values[0]];
      const embed = new EmbedBuilder()
        .setColor('#7B2FBE')
        .setTitle(`${cat.emoji} ${cat.nome}`)
        .setDescription(cat.comandos.join('\n'))
        .setFooter({ text: 'Sentinela Bot • Ajuda' })
        .setTimestamp();

      await i.update({ embeds: [embed], components: [row] });
    });

    collector.on('end', () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  },
};
