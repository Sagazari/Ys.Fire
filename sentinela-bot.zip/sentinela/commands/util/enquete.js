const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const emojisNumero = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('enquete')
    .setDescription('📊 Crie uma enquete rápida')
    .addStringOption(opt => opt.setName('pergunta').setDescription('Qual a pergunta?').setRequired(true))
    .addStringOption(opt => opt.setName('opcoes').setDescription('Opções separadas por vírgula (mín. 2, máx. 10)').setRequired(true)),

  async execute(interaction) {
    const pergunta = interaction.options.getString('pergunta');
    const opcoes = interaction.options.getString('opcoes').split(',').map(o => o.trim()).filter(Boolean);

    if (opcoes.length < 2) return interaction.reply({ content: '❌ Coloque pelo menos 2 opções!', ephemeral: true });
    if (opcoes.length > 10) return interaction.reply({ content: '❌ Máximo 10 opções!', ephemeral: true });

    const linhas = opcoes.map((op, i) => `${emojisNumero[i]} ${op}`).join('\n');

    const embed = new EmbedBuilder()
      .setColor('#7B2FBE')
      .setTitle(`📊 ${pergunta}`)
      .setDescription(linhas)
      .setFooter({ text: `Enquete criada por ${interaction.user.username} • Sentinela Bot` })
      .setTimestamp();

    const msg = await interaction.reply({ embeds: [embed], fetchReply: true });

    for (let i = 0; i < opcoes.length; i++) {
      await msg.react(emojisNumero[i]);
    }
  },
};
