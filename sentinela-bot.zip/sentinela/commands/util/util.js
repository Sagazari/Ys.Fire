const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

// ─── /ping ────────────────────────────────────────────────
const ping = {
  data: new SlashCommandBuilder().setName('ping').setDescription('🏓 Latência do bot'),
  async execute(interaction) {
    const sent = await interaction.reply({ content: '🏓 Calculando...', fetchReply: true });
    const latencia = sent.createdTimestamp - interaction.createdTimestamp;
    const wsLatencia = interaction.client.ws.ping;

    await interaction.editReply({
      content: null,
      embeds: [new EmbedBuilder()
        .setColor(latencia < 100 ? '#00C851' : latencia < 200 ? '#FFD700' : '#FF6B6B')
        .setTitle('🏓 Pong!')
        .addFields(
          { name: '⚡ Latência', value: `**${latencia}ms**`, inline: true },
          { name: '💓 Heartbeat', value: `**${wsLatencia}ms**`, inline: true },
        )
        .setFooter({ text: 'Sentinela Bot • Ping' })],
    });
  },
};

// ─── /avatar ─────────────────────────────────────────────
const avatar = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('🖼️ Veja o avatar de alguém')
    .addUserOption(opt => opt.setName('usuario').setDescription('Usuário').setRequired(false)),
  async execute(interaction) {
    const alvo = interaction.options.getUser('usuario') || interaction.user;
    const url = alvo.displayAvatarURL({ size: 1024, dynamic: true });

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#7B2FBE')
        .setTitle(`🖼️ Avatar de ${alvo.username}`)
        .setImage(url)
        .addFields({ name: '🔗 Link', value: `[Clique aqui](${url})` })
        .setFooter({ text: 'Sentinela Bot • Avatar' })],
    });
  },
};

// ─── /serverinfo ─────────────────────────────────────────
const serverinfo = {
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('🏰 Informações do servidor'),
  async execute(interaction) {
    const g = interaction.guild;
    await g.fetch();

    const embed = new EmbedBuilder()
      .setColor('#7B2FBE')
      .setTitle(`🏰 ${g.name}`)
      .setThumbnail(g.iconURL({ size: 256 }))
      .addFields(
        { name: '👑 Dono', value: `<@${g.ownerId}>`, inline: true },
        { name: '👥 Membros', value: `${g.memberCount}`, inline: true },
        { name: '📅 Criado em', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '💬 Canais', value: `${g.channels.cache.size}`, inline: true },
        { name: '🎭 Cargos', value: `${g.roles.cache.size}`, inline: true },
        { name: '😀 Emojis', value: `${g.emojis.cache.size}`, inline: true },
        { name: '🆔 ID', value: g.id, inline: false },
      )
      .setFooter({ text: 'Sentinela Bot • Server Info' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

// ─── /userinfo ───────────────────────────────────────────
const userinfo = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('👤 Informações de um usuário')
    .addUserOption(opt => opt.setName('usuario').setDescription('Usuário').setRequired(false)),
  async execute(interaction) {
    const alvo = interaction.options.getMember('usuario') || interaction.member;
    const user = alvo.user;

    const cargos = alvo.roles.cache
      .filter(r => r.name !== '@everyone')
      .sort((a, b) => b.position - a.position)
      .first(5)
      .map(r => `<@&${r.id}>`)
      .join(', ') || 'Nenhum';

    const embed = new EmbedBuilder()
      .setColor(alvo.displayHexColor || '#7B2FBE')
      .setTitle(`👤 ${user.username}`)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: '🏷️ Tag', value: user.tag, inline: true },
        { name: '🆔 ID', value: user.id, inline: true },
        { name: '🤖 Bot?', value: user.bot ? 'Sim' : 'Não', inline: true },
        { name: '📅 Conta criada', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '📥 Entrou no servidor', value: `<t:${Math.floor(alvo.joinedTimestamp / 1000)}:D>`, inline: true },
        { name: '🎭 Cargos', value: cargos, inline: false },
      )
      .setFooter({ text: 'Sentinela Bot • User Info' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

// ─── /sorteio simples ────────────────────────────────────
const sortear = {
  data: new SlashCommandBuilder()
    .setName('sortear')
    .setDescription('🎯 Sorteia um número aleatório')
    .addIntegerOption(opt => opt.setName('min').setDescription('Mínimo').setRequired(false))
    .addIntegerOption(opt => opt.setName('max').setDescription('Máximo').setRequired(false)),
  async execute(interaction) {
    const min = interaction.options.getInteger('min') ?? 1;
    const max = interaction.options.getInteger('max') ?? 100;
    if (min >= max) return interaction.reply({ content: '❌ O mínimo deve ser menor que o máximo!', ephemeral: true });

    const numero = Math.floor(Math.random() * (max - min + 1)) + min;
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#7B2FBE')
        .setTitle('🎯 Número Sorteado!')
        .setDescription(`**${numero}**\n\n*(entre ${min} e ${max})*`)
        .setFooter({ text: 'Sentinela Bot • Sorteio' })],
    });
  },
};

// ─── /say ────────────────────────────────────────────────
const say = {
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('💬 Faz o Sentinela falar algo')
    .addStringOption(opt => opt.setName('mensagem').setDescription('O que dizer').setRequired(true)),
  async execute(interaction) {
    const msg = interaction.options.getString('mensagem');
    await interaction.reply({ content: '✅', ephemeral: true });
    await interaction.channel.send(msg);
  },
};

module.exports = [ping, avatar, serverinfo, userinfo, sortear, say];
