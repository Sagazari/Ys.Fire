const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '../data/sentinela.db'));

// Ativa WAL mode para melhor performance
db.pragma('journal_mode = WAL');

// Criação das tabelas
db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id TEXT PRIMARY KEY,
    username TEXT,
    aura INTEGER DEFAULT 0,
    aura_total INTEGER DEFAULT 0,
    last_daily TEXT DEFAULT NULL,
    last_trabalho TEXT DEFAULT NULL,
    last_crime TEXT DEFAULT NULL,
    last_roubo TEXT DEFAULT NULL,
    nivel INTEGER DEFAULT 1,
    xp INTEGER DEFAULT 0,
    casado_com TEXT DEFAULT NULL,
    data_casamento TEXT DEFAULT NULL,
    mortes INTEGER DEFAULT 0,
    wins INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS inventario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    item TEXT NOT NULL,
    quantidade INTEGER DEFAULT 1,
    FOREIGN KEY(user_id) REFERENCES usuarios(id)
  );

  CREATE TABLE IF NOT EXISTS giveaways (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT UNIQUE,
    channel_id TEXT,
    guild_id TEXT,
    premio TEXT,
    aura INTEGER DEFAULT 0,
    host_id TEXT,
    vencedores INTEGER DEFAULT 1,
    termina_em TEXT,
    ativo INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS giveaway_participantes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    giveaway_id INTEGER,
    user_id TEXT,
    UNIQUE(giveaway_id, user_id),
    FOREIGN KEY(giveaway_id) REFERENCES giveaways(id)
  );

  CREATE TABLE IF NOT EXISTS shop (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT UNIQUE,
    descricao TEXT,
    preco INTEGER,
    emoji TEXT,
    ativo INTEGER DEFAULT 1
  );
`);

// Insere itens padrão da loja se não existirem
const shopItems = [
  { nome: 'Escudo de Aura', descricao: 'Protege contra roubo por 24h', preco: 500, emoji: '🛡️' },
  { nome: 'Amuleto da Sorte', descricao: 'Dobra o ganho do Daily por 1 dia', preco: 800, emoji: '🍀' },
  { nome: 'Capa do Ladrão', descricao: 'Aumenta chances no crime por 24h', preco: 1200, emoji: '🥷' },
  { nome: 'Poção de XP', descricao: 'Ganha 500 XP instantaneamente', preco: 300, emoji: '⚗️' },
  { nome: 'Anel de Casamento', descricao: 'Necessário para se casar', preco: 2000, emoji: '💍' },
  { nome: 'Ticket de Sorte', descricao: 'Aumenta suas chances no giveaway', preco: 150, emoji: '🎟️' },
  { nome: 'Elixir de Aura', descricao: 'Ganha 1000 de Aura na hora', preco: 900, emoji: '✨' },
  { nome: 'Buquê de Flores', descricao: 'Para presentear alguém especial', preco: 200, emoji: '💐' },
];

const insertShopItem = db.prepare(`
  INSERT OR IGNORE INTO shop (nome, descricao, preco, emoji)
  VALUES (@nome, @descricao, @preco, @emoji)
`);

for (const item of shopItems) {
  insertShopItem.run(item);
}

// ─── Helpers ───────────────────────────────────────────────

function getUser(id, username = '') {
  let user = db.prepare('SELECT * FROM usuarios WHERE id = ?').get(id);
  if (!user) {
    db.prepare('INSERT OR IGNORE INTO usuarios (id, username) VALUES (?, ?)').run(id, username);
    user = db.prepare('SELECT * FROM usuarios WHERE id = ?').get(id);
  }
  return user;
}

function addAura(id, quantidade) {
  db.prepare('UPDATE usuarios SET aura = aura + ?, aura_total = aura_total + ? WHERE id = ?')
    .run(quantidade, quantidade > 0 ? quantidade : 0, id);
}

function removeAura(id, quantidade) {
  const user = getUser(id);
  const remover = Math.min(quantidade, user.aura);
  db.prepare('UPDATE usuarios SET aura = aura - ? WHERE id = ?').run(remover, id);
  return remover;
}

function setAura(id, quantidade) {
  db.prepare('UPDATE usuarios SET aura = ? WHERE id = ?').run(quantidade, id);
}

function addXP(id, xp) {
  const user = getUser(id);
  let novoXP = user.xp + xp;
  let novoNivel = user.nivel;
  const xpNecessario = novoNivel * 500;

  if (novoXP >= xpNecessario) {
    novoXP -= xpNecessario;
    novoNivel++;
  }

  db.prepare('UPDATE usuarios SET xp = ?, nivel = ? WHERE id = ?').run(novoXP, novoNivel, id);
  return { levelUp: novoNivel > user.nivel, novoNivel };
}

function getRanking(limit = 10) {
  return db.prepare('SELECT * FROM usuarios ORDER BY aura DESC LIMIT ?').all(limit);
}

function getInventario(userId) {
  return db.prepare('SELECT * FROM inventario WHERE user_id = ?').all(userId);
}

function addItem(userId, item) {
  const existing = db.prepare('SELECT * FROM inventario WHERE user_id = ? AND item = ?').get(userId, item);
  if (existing) {
    db.prepare('UPDATE inventario SET quantidade = quantidade + 1 WHERE user_id = ? AND item = ?').run(userId, item);
  } else {
    db.prepare('INSERT INTO inventario (user_id, item) VALUES (?, ?)').run(userId, item);
  }
}

function removeItem(userId, item) {
  const existing = db.prepare('SELECT * FROM inventario WHERE user_id = ? AND item = ?').get(userId, item);
  if (!existing) return false;
  if (existing.quantidade <= 1) {
    db.prepare('DELETE FROM inventario WHERE user_id = ? AND item = ?').run(userId, item);
  } else {
    db.prepare('UPDATE inventario SET quantidade = quantidade - 1 WHERE user_id = ? AND item = ?').run(userId, item);
  }
  return true;
}

function hasItem(userId, item) {
  return !!db.prepare('SELECT * FROM inventario WHERE user_id = ? AND item = ?').get(userId, item);
}

module.exports = {
  db,
  getUser,
  addAura,
  removeAura,
  setAura,
  addXP,
  getRanking,
  getInventario,
  addItem,
  removeItem,
  hasItem,
};
