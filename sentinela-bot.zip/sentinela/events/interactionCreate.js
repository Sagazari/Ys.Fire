const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction, client);
    } catch (error) {
      console.error(`❌ Erro no comando /${interaction.commandName}:`, error);

      const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('❌ Ocorreu um erro!')
        .setDescription('Algo deu errado ao executar esse comando. Tenta de novo!')
        .setFooter({ text: 'Sentinela Bot' });

      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ embeds: [embed], ephemeral: true });
      } else {
        await interaction.reply({ embeds: [embed], ephemeral: true });
      }
    }
  },
};
