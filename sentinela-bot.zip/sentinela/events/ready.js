const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`\n🟢 Sentinela online como ${client.user.tag}`);
    console.log(`📊 Servidores: ${client.guilds.cache.size}`);
    console.log(`👥 Usuários: ${client.users.cache.size}\n`);

    const atividades = [
      { name: '✨ Distribuindo Aura', type: ActivityType.Playing },
      { name: '💒 Casamentos épicos', type: ActivityType.Watching },
      { name: '🎁 /giveaway', type: ActivityType.Playing },
      { name: '🎯 /daily para ganhar Aura', type: ActivityType.Listening },
      { name: `🏰 ${client.guilds.cache.size} servidores`, type: ActivityType.Watching },
    ];

    let i = 0;
    client.user.setActivity(atividades[0].name, { type: atividades[0].type });

    setInterval(() => {
      i = (i + 1) % atividades.length;
      client.user.setActivity(atividades[i].name, { type: atividades[i].type });
    }, 15000);
  },
};
